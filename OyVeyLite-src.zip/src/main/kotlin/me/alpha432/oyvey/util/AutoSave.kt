package me.alpha432.oyvey.util

import me.alpha432.oyvey.OyVey
import java.io.File
import java.io.IOException

object AutoSave {
        @JvmStatic
        @Synchronized
        fun autoSave() {
            val path = File(OyVey.CFGPATH + "autosave/")
            if (!path.exists())
                path.mkdir()
            OyVey.friendManager.saveFriends()
            for (feature in OyVey.configManager.features) {
                try {
                    OyVey.configManager.saveSettings(feature)
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
        }
}
